﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connius.Class
{
    class ImageClass
    {
        public string Name { get; set; }
        public string ImgSize { get; set; }
        public string Mipmap { get; set; }

        public string FileLocation { get; set; }
    }
}
