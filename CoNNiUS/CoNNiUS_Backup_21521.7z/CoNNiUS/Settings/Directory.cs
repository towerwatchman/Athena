﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connius.Settings
{
    public static class Directory
    {
        public static string PythonDirectory
        {
            get;
            set;
        }
        public static string OutputDirectory
        {
            get;
            set;
        }
        public static string ImageDirectory
        {
            get;
            set;
        }
        public static string ModelDirectory
        {
            get;
            set;
        }
    }
}
